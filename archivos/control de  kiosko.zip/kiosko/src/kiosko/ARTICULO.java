/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kiosko;

/**
 *
 * @author XTREME GAMER
 */
public class ARTICULO {
    private long CODbarra;
    private String nombre;
    private double precio;
    private int STOCKactual;

public ARTICULO(){
this.CODbarra=0;
this.nombre="";
this.precio=0;
this.STOCKactual=0;}

    public ARTICULO(long CODbarra, String nombre, double precio, int STOCKactual) {
        this.CODbarra = CODbarra;
        this.nombre = nombre;
        this.precio = precio;
        this.STOCKactual = STOCKactual;
    }

    /**
     * @return the CODbarra
     */
    public long getCODbarra() {
        return CODbarra;
    }

    /**
     * @param CODbarra the CODbarra to set
     */
    public void setCODbarra(long CODbarra) {
        this.CODbarra = CODbarra;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * @return the STOCKactual
     */
    public int getSTOCKactual() {
        return STOCKactual;
    }

    /**
     * @param STOCKactual the STOCKactual to set
     */
    public void setSTOCKactual(int STOCKactual) {
        this.STOCKactual = STOCKactual;
    }
    
  public int comprar(int cantidad){
  this.STOCKactual=STOCKactual+ cantidad;
  return STOCKactual;
  }  
  public double vender (int cantidad){
  if(this.STOCKactual>=cantidad){
      this.STOCKactual=STOCKactual-cantidad;
      return cantidad*precio;
  }else{
  return -1;}
  }

   
    public String toString() {
        return "ARTICULO{" + "CODbarra=" + CODbarra + ", nombre=" + nombre + ", precio=" + precio + ", STOCKactual=" + STOCKactual + '}';
    }
  
    
}
