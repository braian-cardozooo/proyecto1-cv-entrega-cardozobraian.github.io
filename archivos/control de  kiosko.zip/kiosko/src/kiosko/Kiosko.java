/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kiosko;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author XTREME GAMER
 */
public class Kiosko {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<RUBRO> listru = new ArrayList();
        int N;
        do {
            System.out.println("============================");
            System.out.println("1)_Dar alta a rubro");
            System.out.println("2)_Dar alta al los articulos");
            System.out.println("3)_Modificación precio de articulo");
            System.out.println("4)_Listar rubros");
            System.out.println("5)_Listar artículos de un rubro");
            System.out.println("6)_Comprar ");
            System.out.println("7)_Vender ");
            System.out.println("8)_ Emitir un listado de artículo discriminados por rubro");
            System.out.println("9)_exit");
            System.out.println("=============================");
            N = sc.nextInt();
            switch (N) {
                case 1:
                     
                     System.out.println("ingrese cod rub");
                    int codR = sc.nextInt();
                    boolean repetido = false;
                    for (RUBRO ru : listru) {
                        if (ru.getCODrubro() == codR) {
                            repetido = true;
                            System.out.println("Codigo repetido");
                            break;
                        }
                    }
                    if (!repetido) {
                        System.out.println("Ingrese descripcion");
                        String des = sc.next();
                        RUBRO rubro1 = new RUBRO(codR, des);
                        listru.add(rubro1);}
                        break;
                case 2:
                    System.out.println("ingresar cod barra ");
                    int codbarra=sc.nextInt();
                    
                    for(RUBRO ru: listru){
                        if(ru.getCODrubro()==codbarra){
                           System.out.println("ingrese cod art");
                            int codA = sc.nextInt();
                            boolean repetido1 = false;
                            
                       for(ARTICULO ar: ru.getListaAR()){
                           if(ar.getCODbarra()==codA){
                               repetido1=true;
                           System.out.println("Codigo repetido");
                                    break;}
                           
                        }if (!repetido1) {
                                System.out.println("Ingrese nombre");
                                String nom = sc.next();
                                System.out.println("Ingrese prec");
                                double pre = sc.nextDouble();
                                System.out.println("Ingrese stock");
                                int stock = sc.nextInt();
                                ARTICULO art1 = new ARTICULO(codA, nom, pre, stock);
                                ru.getListaAR().add(art1);}
                        
                    }}
                    
                    break;
                case 3:

                    for (int i = 0; i < listru.size(); i++) {
                        System.out.println("ingresar codigo de rubro y codebarraart ");
                        int codru2 = sc.nextInt();
                        System.out.println("ingresar cod de barra art");
                        long codbarart = sc.nextLong();
                        if (codru2 == listru.get(i).getCODrubro() && codbarart == listru.get(i).getListaAR().get(i).getCODbarra()) {
                            int nuevoprecioart = sc.nextInt();
                            listru.get(i).getListaAR().get(i).setPrecio(nuevoprecioart);
                        }
                    }
                    break;
                case 4:
                    for(int i=0; i<listru.size();i++){
                        System.out.println(listru.get(i).toString());}
                    break;
                case 5:
                    for(int i=0;i<listru.size();i++){
                    System.out.println("ingresar codigo de rubro y cod de barra de articulo");
                    int codrubro3=sc.nextInt();
                    System.out.println("ingresar cod de barra de articulo");
                    long codebarraart=sc.nextLong();
                            
                   if(codrubro3==listru.get(i).getCODrubro() && codebarraart== listru.get(i).getListaAR().get(i).getCODbarra()){
                       System.out.println(listru.get(i).toStringART());
                   }}
                    break;
                case 6:
                    
                    for(int i=0;i<listru.size();i++){
                        System.out.println("ingresar codigo de rubro y cod de barra de articulo");
                    int codrubro4=sc.nextInt();
                    long cosbarart4=sc.nextLong();
                    System.out.println("ingresar la cantidad");
                    int cantidad2=sc.nextInt();
                    if(codrubro4==listru.get(i).getCODrubro() && cosbarart4== listru.get(i).getListaAR().get(i).getCODbarra()){
                    listru.get(i).getListaAR().get(i).comprar(cantidad2);}
                    }
                    break;
                case 7:
                    for(int i=0;i<listru.size();i++){
                        System.out.println("ingresar codigo de rubro y cod de barra de articulo");
                    int codrubro5=sc.nextInt();
                    long cosbarart5=sc.nextLong();
                    System.out.println("ingresar la cantidad");
                    int cantidad3=sc.nextInt();
                    if(codrubro5==listru.get(i).getCODrubro() && cosbarart5== listru.get(i).getListaAR().get(i).getCODbarra()){
                    listru.get(i).getListaAR().get(i).vender(cantidad3);}
                    }
                    break;
                case 8:for (int i = 0; i < listru.size(); i++) {
                        int codRub9 = listru.get(i).getCODrubro();
                        String descRub9 = listru.get(i).getDescripcion();
                        System.out.println("Rubro: "+descRub9+"                 "+"                     "+"Codigo de rubro: "+codRub9);
                        System.out.println("Articulo CodBarras "+" Articulo Nombre "+"  Precio "+" Stock Actual              ");
                        for (int j = 0; j < listru.get(i).getListaAR().size(); j++) {
                            long codBarras9 = listru.get(i).getListaAR().get(j).getCODbarra();
                            String nombre9 = listru.get(i).getListaAR().get(j).getNombre();
                            double precio9 = listru.get(i).getListaAR().get(j).getPrecio();
                            int stockActual9 = listru.get(i).getListaAR().get(j).getSTOCKactual();
                            System.out.println(codBarras9+"                 "+nombre9+"     "+precio9 +"      "+stockActual9+"               ");       
                        }        
                    }
                    break;
            }
        } while (N != 9);

    }

}
