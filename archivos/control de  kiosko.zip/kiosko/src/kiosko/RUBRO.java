/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kiosko;

import java.util.ArrayList;

/**
 *
 * @author XTREME GAMER
 */
public class RUBRO {

    private int CODrubro;
    private String descripcion;
    private ArrayList<ARTICULO> listaAR;

    public RUBRO() {
        this.CODrubro = 0;
        this.descripcion = "";
        this.listaAR = new ArrayList();
    }

    public RUBRO(int CODrubro, String descripcion) {
        this.CODrubro = CODrubro;
        this.descripcion = descripcion;
        this.listaAR = new ArrayList();
    }

    /**
     * @return the CODrubro
     */
    public int getCODrubro() {
        return CODrubro;
    }

    /**
     * @param CODrubro the CODrubro to set
     */
    public void setCODrubro(int CODrubro) {
        this.CODrubro = CODrubro;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the listaAR
     */
    public ArrayList<ARTICULO> getListaAR() {
        return listaAR;
    }

    /**
     * @param listaAR the listaAR to set
     */
    public void setListaAR(ArrayList<ARTICULO> listaAR) {
        this.listaAR = listaAR;
    }
    public ArrayList<ARTICULO> FiltoART(String nombre){
        ArrayList<ARTICULO>lista=new ArrayList();
        for(int i=0;i<listaAR.size();i++){
           String ARTnombre=listaAR.get(i).getNombre();
        if(ARTnombre.startsWith(nombre)){
        lista.add(lista.get(i));}}
     return lista;
    }

 
    public String toString() {
        return "RUBRO{" + "CODrubro=" + CODrubro + ", descripcion=" + descripcion + '}';
    }
   public String toStringART(){
   String datos="";
   for(int i=0; i<listaAR.size();i++){
   datos +=listaAR.get(i).toString();}
   return datos;
   }
}
