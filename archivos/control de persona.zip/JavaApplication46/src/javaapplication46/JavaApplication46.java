package javaapplication46;

import java.util.Scanner;

public class JavaApplication46 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("INGREDAR DATOS :");
        System.out.println("==================");
        System.out.println("INGRESAR NOMBRE:");
        String NOMBRE = sc.next();
        System.out.println("INGRESAR EDAD:");
        int EDAD = sc.nextInt();
        System.out.println("INGRESAR DNI:");
        long DNI = sc.nextLong();
        System.out.println("INGRESAR SEXO(M=MASCULINO//F=EMENINO):");
        char SEXO = sc.next().charAt(0);
        System.out.println("INGRESAR PESO:");
        int PESO = sc.nextInt();
        System.out.println("INGRESAR ALTURA:");
        double ALTURA = sc.nextDouble();
        System.out.println("==================");
        persona persona1 = new persona(NOMBRE, EDAD, DNI, SEXO, PESO, ALTURA);
        int N;
        do {
            System.out.println("============================");
            System.out.println("MENU DE OPCCIONES");
            System.out.println("1)_para calcular imc");
            System.out.println("2)_para identifivar si es mayor de edad");
            System.out.println("3)_para determinar el sexo");
            System.out.println("4)_obtenet todo la info de la perdona ");
            System.out.println("5)_salir");
            N = sc.nextInt();
            switch (N) {
                case 1 :
                    System.out.println("==================");
                    System.out.println(persona1.calcularIMC());
                    System.out.println("==================");
                    break;
                case 2:
                    System.out.println("==================");
                    System.out.println(persona1.mayorDEedad());
                    System.out.println("==================");
                    break;
                case 3: 
                    System.out.println("=========M=MASCULINO//F=EMENINO=========");
                    System.out.println(persona1.comprobrarSEXO(sc.next().charAt(0)));
                    System.out.println("==================");
                    break;
                case 4:
                    System.out.println("==================");
                    System.out.println(persona1.toString());
                    System.out.println("==================");
                    break;
                    
            }

        }while(N<5);

    }

}
