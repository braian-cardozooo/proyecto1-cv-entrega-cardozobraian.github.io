package javaapplication39;

import java.util.Scanner;

/**
 *
 * @author BRAIAN CARDOZO
 */
public class JavaApplication39 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);//llamada del escaner
        //de aqui en adelande se pide el ingreso de los datos (datos que se guardan en los constuctores con parametros)
        System.out.println("============================");
        System.out.println("ingrese el NUMERO DE CUENTA: ");
        long numeroDEcuenta = sc.nextLong();
        System.out.println("ingrese su DNI: ");
        long dni = sc.nextLong();
        System.out.println("ingrese su APELLIDO");
        String apellido = sc.next();
        System.out.println("ingese su NOMBRE");
        String nombre = sc.next();
        System.out.println("ingrese el SALDO");
        double saldo = sc.nextDouble();
        System.out.println("ingrese el TIPO DE CUENTA(TRUNE PARA"
                + "cuentaCORRIENTE O FALSE PARA CAJA DE AHORRO)");
        boolean cuentaCORRIENTE = sc.nextBoolean();
        System.out.println("============================");
        //lo siguente se llama instanciar un costructor
        //(o llamar al constructor esto hace que los dattos ingresado se depositen en el costructor con parametros)
        cuentaBancaria cuentaB1 = new cuentaBancaria(numeroDEcuenta, dni,
                apellido, nombre, saldo, cuentaCORRIENTE);
        int N;
        // el do while funciona asi en el do imprime los que quieres 
        //el while es la condidio osea ejemplo (si n es <10 entonces improme lo que esta en el do) 
         do {
            // aqui estas haciendo el menu de inicio 
            System.out.println("======================");
            System.out.println("1)_DEPOSITAR ");
            System.out.println("2)_ EXTRAER");
            System.out.println("3)_VER SALDO DE LA CUENTA");
            System.out.println("4)_VER DATOS DEL TITULAR DE LA CUENTA");
            System.out.println("5)_VER TODO LOS DATOS DE LA CUENTA");
            System.out.println("6)_PARA SALIR DEL MENU");
            System.out.println("==========================");
            N = sc.nextInt();//haces un ingreso y lo depositas en el switch
            // el switch funciona asi encada case pones algo si vos ingresa 2 te improme lo del case 2 
            switch (N) {
                case 1:
                    System.out.println("======================");
                    System.out.println("ingrese el montoo a depositar");
                    System.out.println(cuentaB1.deposito(sc.nextDouble()));
                    System.out.println("======================");
                    break;
                case 2:
                    System.out.println("======================");
                    System.out.println("ingrese el monto a extraer");
                    System.out.println(cuentaB1.montoAextraer(sc.nextDouble()));
                    System.out.println("======================");
                    break;
                case 3:
                    System.out.println("======================");
                    System.out.println("EL SALDO DE LA CUENTA ES DE:");
                    System.out.println(cuentaB1.toString());
                    System.out.println("======================");
                    break;
                case 4:
                    System.out.println("======================");
                    System.out.println("DATOS DEL TITULAR DE LA CUENTA:");
                    System.out.println(cuentaB1.toString2());
                    System.out.println("======================");
                    break;
                case 5:
                    System.out.println("======================");
                    System.out.println("TODO LOS DATOS DE LA CUENT:");
                    System.out.println(cuentaB1.toString3());
                    System.out.println("======================");
                    break;
            }
        } while (N != 6);
    }

}
