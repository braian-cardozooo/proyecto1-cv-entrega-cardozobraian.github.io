package javaapplication39;

/**
 *
 * @author BRAIAN CARDOZO
 */
public class cuentaBancaria {
//lo siguentes se llamas atributos que son equivalentes a las variavles
    private long numeroDEcuenta;
    private long dni;
    private String apellido;
    private String nombre;
    private double saldo;
    private boolean cuentaCORRIENTE;
//estos son los codtructores sin parametros (que son los parametros lo que va desntro de los parentecis) 
    public cuentaBancaria() {// en este constructor se lo define en 0 para los enteros y los long 
        //0.0 para los doubles y "" para los string
        this.numeroDEcuenta = 0;
        this.dni = 0;
        this.apellido = "";
        this.nombre = "";
        this.saldo = 0.0;
        this.cuentaCORRIENTE = true;
    }
     //constructor con parametros aqui se depositan los datos que se ingresan en el metodo main 
    public cuentaBancaria(long numeroDEcuenta, long dni, String apellido,
            String nombre, double saldo, boolean cuentaCORRIENTE) {
        //en el constructor simmpre se lo iguala al minmo nombre
        this.numeroDEcuenta = numeroDEcuenta;
        this.dni = dni;
        this.apellido = apellido;
        this.nombre = nombre;
        this.saldo = saldo;
        this.cuentaCORRIENTE = cuentaCORRIENTE;
    }
      //aqui se enccpsula los atributos .como se hace? clik derecho vas a refactor y encapsulate fields.. 
    /**
     * @return the numeroDEcuenta
     */
    public long getNumeroDEcuenta() {
        return numeroDEcuenta;
    }

    /**
     * @param numeroDEcuenta the numeroDEcuenta to set
     */
    public void setNumeroDEcuenta(long numeroDEcuenta) {
        this.numeroDEcuenta = numeroDEcuenta;
    }

    /**
     * @return the dni
     */
    public long getDni() {
        return dni;
    }

    /**
     * @param dni the dni to set
     */
    public void setDni(long dni) {
        this.dni = dni;
    }

    /**
     * @return the apellido
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the apellido to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    /**
     * @return the cuentaCORRIENTE
     */
    public boolean isCuentaCORRIENTE() {
        return cuentaCORRIENTE;
    }

    /**
     * @param cuentaCORRIENTE the cuentaCORRIENTE to set
     */
    public void setCuentaCORRIENTE(boolean cuentaCORRIENTE) {
        this.cuentaCORRIENTE = cuentaCORRIENTE;
    }
    // de aqui en adelante se hace los que el profe pide ejemplo :
    //1)_lo siguente sitve para ingresar mas dinero
    public double deposito(double MONTO_A_DEPOSITAR) {
        return this.saldo=saldo + MONTO_A_DEPOSITAR;
    }
//2)_ para extraer
    public double montoAextraer(double MONTO_A_EXTRAER) {
        //si es cuenta corrien hace esto
        if (cuentaCORRIENTE == true) {
            if (saldo  <= MONTO_A_EXTRAER) {
                this.saldo = saldo - MONTO_A_EXTRAER;
            }
        } else {
            //en caso de no hacerlo hace esto
            if (cuentaCORRIENTE == false) {
                if (MONTO_A_EXTRAER <= this.getSaldo()) {
                    saldo = saldo - MONTO_A_EXTRAER;
                }
            }
        }
        return saldo;

    }
    // los toString sirven para mostrar siertos datos :
    //3)_ mostrar saldo de la cuenta 
    public String toString() {
        return "saldo de la cuenta:" + saldo;
    }
    //4)_para mostrar datos del titular de la cuentas
    public String toString2() {
        return "dni: " + dni + ", apellido: " + apellido + " ,nombre: " + nombre;
    }
     //5)_para mostrar todo los tados 
    public String toString3() {
        return "dni: " + dni + ", apellido: " + apellido + " ,nombre: " + nombre
                + ", numer de cuenta: " + numeroDEcuenta + ", tipo de cuenta: "
                + cuentaCORRIENTE + "saldo de la cuenta:" + saldo;
    }
}
