package javaapplication47deu;

import java.util.Scanner;

public class JavaApplication47deu {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("===================================");
        System.out.println("INGRESA DATOS ");
        System.out.println("===================================");
        System.out.println("INGRESAR DNI: ");
        long DNI = sc.nextLong();
        System.out.println("INGRESAR APELLIDO ");
        String APELLIDO = sc.next();
        System.out.println("INGRESAR NOMBRE :");
        String NOMBRE = sc.next();
        System.out.println("DNIcoTITULAR:");
        long DNIcoTITULAR = sc.nextLong();
        System.out.println("INGRESAR APELLIDO DEL COTITULAR: ");
        String ApcoTITULAR = sc.next();
        System.out.println("INGRESAR NOMBRE DEL COTITULAR");
        String NOMBREcoTITULAR = sc.next();
        System.out.println("INGRESAR MONTOadeudado");
        double MONTOadeudado = sc.nextDouble();
        System.out.println("ingresar añoADEUDADO");
        int añoADEUDADO = sc.nextInt();
        System.out.println("===================================");
        deudores deudores1 = new deudores(DNI, APELLIDO, NOMBRE, DNIcoTITULAR,
                ApcoTITULAR, NOMBREcoTITULAR, MONTOadeudado, añoADEUDADO);
        int N;
        do {
            System.out.println("BIENVENIDO AL MENU DE OPVIONES ");
            System.out.println("===================================");
            System.out.println("1)_para calacular la deuda actual");
            System.out.println("2)_para Realizar Plan De Pago");
            System.out.println("3)_Cambiar Cotitular");
            System.out.println("4)_Ver datos personales del deudor");
            System.out.println("5)_Ver datos personales del cotitular");
            System.out.println("6)_Ver todos los datos del deudor");
            System.out.println("7)_ para salir del menu ");
            N = sc.nextInt();
            switch (N) {
                case 1:
                    System.out.println("===================================");
                    System.out.println(deudores1.CalcularDeudaActual());
                    System.out.println("===================================");
                    break;
                case 2:
                    System.out.println("===================================");
                    System.out.println(deudores1.RealizarPlanDePago(sc.nextInt()));
                    System.out.println("===================================");
                    break;
                case 3: 
                   System.out.println("==========================");
                    System.out.println("ingresar DNIcotitular");
                    deudores1.setDniCOTI(sc.nextLong());
                    System.out.println("==========================");
                    System.out.println("==========================");
                    System.out.println("Apellido nuevo de COTITULAR: ");
                    
                    deudores1.setApellidoCOTI(sc.next());
                    System.out.println("==========================");
                    System.out.println("==========================");
                    System.out.println("Nombre nuevo de COTITULAR: ");
                    
                    deudores1.setNombreCOTI(sc.next());
                    System.out.println("==========================");
                     System.out.println("==========================");
                    deudores1.setMontoAdeudado(deudores1.getMontoAdeudado()
                            + (deudores1.getMontoAdeudado() * 5 / 10));
                    System.out.println("==========================");
                    break;
                case 4:
                    System.out.println("==========================");
                    System.out.println(deudores1.toString());
                    System.out.println("==========================");
                    break;
                case 5:
                    System.out.println("==========================");
                    System.out.println(deudores1.toString1());
                    System.out.println("==========================");
                    break;
                case 6: 
                    System.out.println("==========================");
                    System.out.println(deudores1.toString2());
                    System.out.println("==========================");
            }
        } while (N != 7);

    }

}
