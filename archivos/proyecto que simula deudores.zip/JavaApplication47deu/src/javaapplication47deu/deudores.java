package javaapplication47deu;

public class deudores {

    private long dni;
    private String apellido;
    private String nombre;
    private long dniCOTI;
    private String apellidoCOTI;
    private String nombreCOTI;
    private double montoAdeudado;
    private int añioadeu;

    public deudores() {
        this.dni = 0;
        this.apellido = "";
        this.nombre = "";
        this.dniCOTI = 0;
        this.apellidoCOTI = "";
        this.nombreCOTI = "";
        this.montoAdeudado = 0.0;
        this.añioadeu = 0;
    }

    public deudores(long dni, String apellido, String nombre, long dniCOTI, String apellidoCOTI, String nombreCOTI, double montoAdeudado, int añioadeu) {
        this.dni = dni;
        this.apellido = apellido;
        this.nombre = nombre;
        this.dniCOTI = dniCOTI;
        this.apellidoCOTI = apellidoCOTI;
        this.nombreCOTI = nombreCOTI;
        this.montoAdeudado = montoAdeudado;
        this.añioadeu = añioadeu;
    }

    /**
     * @return the dni
     */
    public long getDni() {
        return dni;
    }

    /**
     * @param dni the dni to set
     */
    public void setDni(long dni) {
        this.dni = dni;
    }

    /**
     * @return the apellido
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the apellido to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the dniCOTI
     */
    public long getDniCOTI() {
        return dniCOTI;
    }

    /**
     * @param dniCOTI the dniCOTI to set
     */
    public void setDniCOTI(long dniCOTI) {
        this.dniCOTI = dniCOTI;
    }

    /**
     * @return the apellidoCOTI
     */
    public String getApellidoCOTI() {
        return apellidoCOTI;
    }

    /**
     * @param apellidoCOTI the apellidoCOTI to set
     */
    public void setApellidoCOTI(String apellidoCOTI) {
        this.apellidoCOTI = apellidoCOTI;
    }

    /**
     * @return the nombreCOTI
     */
    public String getNombreCOTI() {
        return nombreCOTI;
    }

    /**
     * @param nombreCOTI the nombreCOTI to set
     */
    public void setNombreCOTI(String nombreCOTI) {
        this.nombreCOTI = nombreCOTI;
    }

    /**
     * @return the montoAdeudado
     */
    public double getMontoAdeudado() {
        return montoAdeudado;
    }

    /**
     * @param montoAdeudado the montoAdeudado to set
     */
    public void setMontoAdeudado(double montoAdeudado) {
        this.montoAdeudado = montoAdeudado;
    }

    /**
     * @return the añioadeu
     */
    public int getAñioadeu() {
        return añioadeu;
    }

    /**
     * @param añioadeu the añioadeu to set
     */
    public void setAñioadeu(int añioadeu) {
        this.añioadeu = añioadeu;
    }

    public double CalcularDeudaActual() {
        int año = 2002 - añioadeu;
        double deudaact = montoAdeudado;
        for (int i = 1; i < año; i++) {
           deudaact= (montoAdeudado*21)/100;
        }
        return deudaact;
    }

    public double RealizarPlanDePago(int meses) {
        double cuotas = CalcularDeudaActual()/ meses;
        double interes = (cuotas *10)/100;
        double interes2 = (cuotas* 19) / 100;
        if (meses > 3) {
            return CalcularDeudaActual()/ meses;
        } else {
            if (meses >= 4 && meses <= 6) {
                 return CalcularDeudaActual() + ( CalcularDeudaActual()* 10)/100;
            } else {
                if (meses >= 7 && meses <= 12) {
                    return cuotas + interes2;
                }
            }
        }
        return 0;
    }

    public void CambiarCotitular( long dniCOTI, String apellidoCOTI, String nombreCOTI) {
        montoAdeudado = montoAdeudado * 1.05;
       this.dniCOTI = dniCOTI;
       this.apellidoCOTI = apellidoCOTI;
       this.nombreCOTI= nombreCOTI;
    }

    public String toString1() {
        return "deudores{" + "dni=" + dni + ", apellido=" + apellido + ", nombre=" + nombre + '}';
    }

    public String toString2() {
        return "deudores{" + "dniCOTI=" + dniCOTI + ", apellidoCOTI=" + apellidoCOTI + ", nombreCOTI=" + nombreCOTI + '}';
    }

    public String toString() {
        return "deudores{" + "dni=" + dni + ", apellido=" + apellido + ", nombre=" + nombre + ", montoAdeudado=" + montoAdeudado + ", a\u00f1ioadeu=" + añioadeu + '}';
    }

    
    }


