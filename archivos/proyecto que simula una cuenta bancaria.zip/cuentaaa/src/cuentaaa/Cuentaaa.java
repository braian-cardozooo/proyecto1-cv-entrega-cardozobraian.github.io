/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuentaaa;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author XTREME GAMER
 */
public class Cuentaaa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        //for (int i = 0; i < 2; i++) {
           /* System.out.println("========================");
         System.out.println("ingresa numero de cuenta");
         long NUMEROdeCUENTA = sc.nextLong();
         System.out.println("ingrese  fecha de apertura");
         String FDA = sc.next();
         System.out.println("ingresar DNI del titular");
         long DNITT = sc.nextLong();
         System.out.println("infresar tipo de cuenta");
         String ACTIVA = "";
         System.out.println("ingresar saldo de la cueta");
         double SALDO = sc.nextDouble();
         System.out.println("========================");

         cuenta cuenta1 = new cuenta(NUMEROdeCUENTA, FDA, DNITT, ACTIVA, SALDO);
         l1.add(cuenta1);*/
        ArrayList<cuenta> l1 = new ArrayList();
        int N = 0;
        do {
            System.out.println("========================");
            System.out.println("bienvenido al menu de inicio");
            System.out.println("1)_Alta de cuenta");
            System.out.println("2)_Depositar");
            System.out.println("3)_Extraer");
            System.out.println("4)_Busqueda por dni");
            System.out.println("5)_Activar cuenta");
            System.out.println("6)_Desactivar cuenta");
            System.out.println("7)_Imprimir todas las cuentas");
            System.out.println("8)_salir");
            System.out.println("========================");
            N = sc.nextInt();

            switch (N) {
                case 1:

                    System.out.println("========================");
                    System.out.println("ingresa numero de cuenta");
                    long nroDeCuenta = sc.nextLong();
                    System.out.println("ingresar DNI del titular");
                    long dni = sc.nextLong();
                    System.out.println("ingrese  fecha de apertura");
                    String fecha = sc.next();
                    //System.out.println("infresar tipo de cuenta");
                    boolean activa = true;
                    System.out.println("ingresar saldo de la cueta");
                    double saldo = sc.nextDouble();
                    System.out.println("========================");
                    cuenta cuentaNueva = new cuenta(nroDeCuenta, dni, fecha, activa, saldo);
                    l1.add(cuentaNueva);

                    break;
                case 2:
                    System.out.println("========================");

                    System.out.println("ingresa numero de cuenta");
                    long nuemroDEcuenta2 = sc.nextLong();
                    System.out.println("ingresar monto de deposito");
                    for (int i = 0; i < l1.size(); i++) {
                        if (nuemroDEcuenta2 == l1.get(i).getNUMEROdeCUENTA()) {
                            l1.get(i).depositar(sc.nextDouble());
                            System.out.println("El deposito fue realizado con exito, su saldo es de:$" + l1.get(i).getSaldo());
                        }
                    }
                    System.out.println("========================");
                    break;
                case 3:
                    System.out.println("========================");
                    System.out.println("ingresa numero de cuenta");
                    long nuemroDEcuenta3 = sc.nextLong();
                    System.out.println("ingresar monto de deposito");
                    for (int i = 0; i < l1.size(); i++) {
                        if (nuemroDEcuenta3 == l1.get(i).getNUMEROdeCUENTA()) {
                            l1.get(i).extraer(sc.nextDouble());
                            System.out.println("La extraccion fue exixtosa du saldo es de :$" + l1.get(i).getSaldo());
                        }
                    }

                    System.out.println("========================");
                    break;
                case 4:
                    System.out.println("========================");
                    System.out.println("ingresar dni");
                    long dni2 = sc.nextLong();
                    for (int i = 0; i < l1.size(); i++) {
                        if (dni2 == l1.get(i).getDNItt()) {
                            System.out.println(l1.get(i).getdato());
                        }
                    }
                    System.out.println("========================");
                    break;
                case 5:
                    System.out.println("========================");
                    System.out.println("ingresar numero de cuenta");
                    long nuemroDEcuenta4 = sc.nextLong();
                    for (int i = 0; i < l1.size(); i++) {
                        if (nuemroDEcuenta4 == l1.get(i).getNUMEROdeCUENTA()) {
                            l1.get(i).activarCuenta();
                        }
                    }
                    System.out.println("========================");

                    break;
                case 6:
                    System.out.println("========================");
                    System.out.println("ingresar numero de cuenta");
                    long nuemroDEcuenta5 = sc.nextLong();
                    for (int i = 0; i < l1.size(); i++) {
                        if (l1.get(i).getNUMEROdeCUENTA() == nuemroDEcuenta5) {
                            l1.get(i).desactivarCuenta();
                        }
                    }
                    System.out.println("========================");
                    break;
                case 7:
                    System.out.println("========================");
                    for (int i = 0; i < l1.size(); i++) {
                        System.out.println(l1.get(i).getdato());
                    }
                    System.out.println("========================");
                    break;
                default:
                    throw new AssertionError();

            }
        } while (N != 8);

    }

}
