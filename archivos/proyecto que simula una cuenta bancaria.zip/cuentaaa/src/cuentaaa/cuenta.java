/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuentaaa;

/**
 *
 * @author XTREME GAMER
 */
public class cuenta {

    private long NUMEROdeCUENTA;
    private long DNItt;
    private String FechaDeApertura;
    private boolean activa;
    private double saldo;

    public cuenta() {
        this.NUMEROdeCUENTA = 0;
        this.DNItt = 0;
        this.FechaDeApertura = "";
        this.activa = true;
        this.saldo = 0.0;
    }

    public cuenta(long NUMEROdeCUENTA, long DNItt, String FechaDeApertura, boolean activa, double saldo) {
        this.NUMEROdeCUENTA = NUMEROdeCUENTA;
        this.DNItt = DNItt;
        this.FechaDeApertura = FechaDeApertura;
        this.activa = activa;
        this.saldo = saldo;
    }

    cuenta(long NUMEROdeCUENTA, String FDA, long DNITT, String ACTIVA, double SALDO) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * @return the NUMEROdeCUENTA
     */
    public long getNUMEROdeCUENTA() {
        return NUMEROdeCUENTA;
    }

    /**
     * @param NUMEROdeCUENTA the NUMEROdeCUENTA to set
     */
    public void setNUMEROdeCUENTA(long NUMEROdeCUENTA) {
        this.NUMEROdeCUENTA = NUMEROdeCUENTA;
    }

    /**
     * @return the DNItt
     */
    public long getDNItt() {
        return DNItt;
    }

    /**
     * @param DNItt the DNItt to set
     */
    public void setDNItt(long DNItt) {
        this.DNItt = DNItt;
    }

    /**
     * @return the FechaDeApertura
     */
    public String getFechaDeApertura() {
        return FechaDeApertura;
    }

    /**
     * @param FechaDeApertura the FechaDeApertura to set
     */
    public void setFechaDeApertura(String FechaDeApertura) {
        this.FechaDeApertura = FechaDeApertura;
    }

    /**
     * @return the activa
     */
    public boolean isActiva() {
        return activa;
    }

    /**
     * @param activa the activa to set
     */
    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public boolean depositar(double monto) {
        if (this.activa == true) {
            this.saldo = this.saldo + monto;
        }
        return true;

    }

    public boolean extraer(double monto) {
        if (this.activa == true && monto <= this.saldo) {
            this.saldo = this.saldo - monto;
        }
        return true;
    }

    public String getdato() {
        return "cuenta{" + "NUMEROdeCUENTA=" + NUMEROdeCUENTA + ", DNItt=" + DNItt + ", FechaDeApertura=" + FechaDeApertura + ", activa=" + activa + ", saldo=" + saldo + '}';
    }

    public void activarCuenta() {
        this.activa = true;

    }

    public void desactivarCuenta() {
        this.activa = false;
    }
}
